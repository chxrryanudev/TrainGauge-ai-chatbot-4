const fetch = require('node-fetch');

exports.handler = async function(event, context) {
    // This allows CORS preflight requests (OPTIONS method)
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 204, // No content for preflight
            headers: {
                'Access-Control-Allow-Origin': 'https://traingaugeai.netlify.app', // Frontend URL for CORS
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
            },
            body: ''
        };
    }

    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            body: JSON.stringify({ message: 'Method Not Allowed' }),
            headers: {
                'Access-Control-Allow-Origin': 'https://traingaugeai.netlify.app', // Frontend URL for CORS
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
            },
        };
    }

    try {
        const body = JSON.parse(event.body);
        const userMessage = body.message;

        if (!userMessage) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'Missing user message in request body' }),
                headers: {
                    'Access-Control-Allow-Origin': 'https://traingaugeai.netlify.app', // Frontend URL for CORS
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS',
                },
            };
        }

        // --- Hardcoded API Key (For this specific request only - NOT for production!) ---
        const GROQ_API_KEY = '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'; // Your API Key
        const GROQ_ENDPOINT = 'https://api.groq.com/openai/v1/chat/completions';

        const groqResponse = await fetch(GROQ_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${GROQ_API_KEY}`
            },
            body: JSON.stringify({
                "model": "mixtral-8x7b-32768",
                "messages": [
                    { "role": "system", "content": "You are TrainGauge AI, a fitness chatbot. Talk like a motivational best friend. Give tips, routines, and YouTube links." },
                    { "role": "user", "content": userMessage }
                ],
                "temperature": 0.7,
                "max_tokens": 1024
            })
        });

        if (!groqResponse.ok) {
            const errorText = await groqResponse.text();
            console.error('Groq API Error:', groqResponse.status, errorText);
            throw new Error('Groq API call failed');
        }

        const groqData = await groqResponse.json();
        const botReply = groqData.choices[0].message.content;

        return {
            statusCode: 200,
            body: JSON.stringify({ reply: botReply }),
            headers: {
                'Access-Control-Allow-Origin': 'https://traingaugeai.netlify.app', // Frontend URL for CORS
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
            },
        };

    } catch (error) {
        console.error('Function error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ reply: "Fitness coach is busy right now. Stay hydrated and rest well 💧😴" }),
            headers: {
                'Access-Control-Allow-Origin': 'https://traingaugeai.netlify.app', // Frontend URL for CORS
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
            },
        };
    }
};
